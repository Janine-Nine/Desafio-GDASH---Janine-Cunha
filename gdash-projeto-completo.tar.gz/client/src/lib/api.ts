const API_BASE = "/api";

export interface WeatherLog {
  id: number;
  timestamp: string;
  location: string;
  temperature: number;
  humidity: number;
  windSpeed: number;
  condition: string;
  precipitationProb: number;
}

export interface User {
  id: number;
  name: string;
  email: string;
  role: string;
  status: string;
  lastLogin: string;
}

export interface Insight {
  id: number;
  type: string;
  title: string;
  description: string;
  severity?: string;
  timestamp: string;
}

export interface AuthResponse {
  token: string;
  user: User;
}

class ApiClient {
  private getToken(): string | null {
    return localStorage.getItem("gdash_token");
  }

  private getHeaders(): HeadersInit {
    const headers: HeadersInit = {
      "Content-Type": "application/json",
    };
    
    const token = this.getToken();
    if (token) {
      headers["Authorization"] = `Bearer ${token}`;
    }
    
    return headers;
  }

  async login(email: string, password: string): Promise<AuthResponse> {
    const response = await fetch(`${API_BASE}/auth/login`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ email, password }),
    });

    if (!response.ok) {
      const error = await response.json();
      throw new Error(error.error || "Login failed");
    }

    const data = await response.json();
    localStorage.setItem("gdash_token", data.token);
    localStorage.setItem("gdash_auth", "true");
    return data;
  }

  async logout() {
    localStorage.removeItem("gdash_token");
    localStorage.removeItem("gdash_auth");
  }

  async getCurrentUser(): Promise<User> {
    const response = await fetch(`${API_BASE}/auth/me`, {
      headers: this.getHeaders(),
    });

    if (!response.ok) {
      throw new Error("Failed to get current user");
    }

    return response.json();
  }

  // Weather endpoints
  async getWeatherLogs(limit?: number): Promise<WeatherLog[]> {
    const url = limit 
      ? `${API_BASE}/weather/logs?limit=${limit}`
      : `${API_BASE}/weather/logs`;
    
    const response = await fetch(url);
    
    if (!response.ok) {
      throw new Error("Failed to fetch weather logs");
    }

    return response.json();
  }

  async exportCSV(): Promise<void> {
    const response = await fetch(`${API_BASE}/weather/export.csv`);
    
    if (!response.ok) {
      throw new Error("Failed to export CSV");
    }

    const blob = await response.blob();
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `weather_data_${new Date().toISOString().split("T")[0]}.csv`;
    document.body.appendChild(a);
    a.click();
    window.URL.revokeObjectURL(url);
    document.body.removeChild(a);
  }

  async exportXLSX(): Promise<void> {
    const response = await fetch(`${API_BASE}/weather/export.xlsx`);
    
    if (!response.ok) {
      throw new Error("Failed to export XLSX");
    }

    const blob = await response.blob();
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `weather_data_${new Date().toISOString().split("T")[0]}.xlsx`;
    document.body.appendChild(a);
    a.click();
    window.URL.revokeObjectURL(url);
    document.body.removeChild(a);
  }

  // Insights endpoints
  async getInsights(limit?: number): Promise<Insight[]> {
    const url = limit
      ? `${API_BASE}/insights?limit=${limit}`
      : `${API_BASE}/insights`;
    
    const response = await fetch(url);
    
    if (!response.ok) {
      throw new Error("Failed to fetch insights");
    }

    return response.json();
  }

  async generateInsights(): Promise<Insight[]> {
    const response = await fetch(`${API_BASE}/insights/generate`, {
      method: "POST",
      headers: this.getHeaders(),
    });
    
    if (!response.ok) {
      throw new Error("Failed to generate insights");
    }

    return response.json();
  }

  // User endpoints
  async getUsers(): Promise<User[]> {
    const response = await fetch(`${API_BASE}/users`, {
      headers: this.getHeaders(),
    });
    
    if (!response.ok) {
      throw new Error("Failed to fetch users");
    }

    return response.json();
  }

  async createUser(userData: Partial<User> & { password: string }): Promise<User> {
    const response = await fetch(`${API_BASE}/users`, {
      method: "POST",
      headers: this.getHeaders(),
      body: JSON.stringify(userData),
    });
    
    if (!response.ok) {
      const error = await response.json();
      throw new Error(error.error || "Failed to create user");
    }

    return response.json();
  }

  async updateUser(id: number, userData: Partial<User>): Promise<User> {
    const response = await fetch(`${API_BASE}/users/${id}`, {
      method: "PATCH",
      headers: this.getHeaders(),
      body: JSON.stringify(userData),
    });
    
    if (!response.ok) {
      throw new Error("Failed to update user");
    }

    return response.json();
  }

  async deleteUser(id: number): Promise<void> {
    const response = await fetch(`${API_BASE}/users/${id}`, {
      method: "DELETE",
      headers: this.getHeaders(),
    });
    
    if (!response.ok) {
      throw new Error("Failed to delete user");
    }
  }
}

export const apiClient = new ApiClient();
