// GDASH 2025 - Main JavaScript
console.log('GDASH Dashboard loaded');

// Add your JavaScript code here
document.addEventListener('DOMContentLoaded', function() {
  console.log('Document ready');
});
